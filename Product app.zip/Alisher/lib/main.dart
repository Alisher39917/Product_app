// main.dart
import 'package:flutter/material.dart';
import 'screens/product_list_screen.dart';

void main() {
  runApp(
    const MaterialApp(
      title: 'Product Explorer',
      home: ProductListScreen(),
      debugShowCheckedModeBanner: false,
    ),
  );
}
