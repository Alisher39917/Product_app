// product_model.dart
import 'package:flutter/material.dart';

class ProductModel {
  final String productImage, productName, productDescription;
  final int productPrice;

  ProductModel({
    required this.productName,
    required this.productImage,
    required this.productPrice,
    required this.productDescription,
  });
}
