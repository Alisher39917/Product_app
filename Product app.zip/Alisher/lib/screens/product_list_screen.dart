// product_list_screen.dart
import 'package:flutter/material.dart';
import '../models/product_model.dart';
import 'product_detail_screen.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  // Defining a list of products
  final List<ProductModel> productCatalog = [
    ProductModel(
      productName: 'Honda CBR500R',
      productImage: 'assets/honda_cbr500r.png',
      productPrice: 700000,
      productDescription: 'A lightweight, sporty bike perfect for beginners and veterans alike.',
    ),
    ProductModel(
      productName: 'Yamaha YZF-R3',
      productImage: 'assets/yamaha_r3.png',
      productPrice: 650000,
      productDescription: 'A high-revving, compact powerhouse, ideal for daily rides and track days.',
    ),
    ProductModel(
      productName: 'Kawasaki Ninja 400',
      productImage: 'assets/kawasaki_ninja400.png',
      productPrice: 750000,
      productDescription: 'A sleek, aggressive bike with responsive handling and superb performance.',
    ),
    ProductModel(
      productName: 'Suzuki GSX250R',
      productImage: 'assets/suzuki_gsx250r.png',
      productPrice: 600000,
      productDescription: 'A well-balanced, efficient bike built for commuting and weekend fun.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Products'),
        backgroundColor: Colors.lightBlue[300],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView.builder(
            itemCount: productCatalog.length,
            itemBuilder: (context, index) {
              var currentProduct = productCatalog[index];
              return Card(
                elevation: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                child: ListTile(
                  leading: Image.asset(currentProduct.productImage),
                  title: Text(currentProduct.productName),
                  subtitle: Text('Price: \RS ${currentProduct.productPrice}'),
                  onTap: () {
                    // Navigating to product detail screen
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            ProductDetailScreen(product: currentProduct),
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
